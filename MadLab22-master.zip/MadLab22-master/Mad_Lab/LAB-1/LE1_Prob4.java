public class LE1_Prob4
{
	public static void main(String[] args){
	    int  x = 4;
	    for ( int i = 1 ; i <=10 ; i++){
		System.out.println(x +" * " + i + " = " + (x*i));  	

	}
     }
}
